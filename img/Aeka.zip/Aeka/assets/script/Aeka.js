window.onscroll = function () {
    scrollFunction()
};

var screenWidth = window.screen.width;

function scrollFunction() {

    if (screenWidth > 991) {
        if (document.body.scrollTop > 215 || document.documentElement.scrollTop > 215) {
            document.getElementById("scroll_navbar").style.top = "0%";
            document.getElementById("img_logo").style.display = "none";
            document.getElementById("scroll_menubar").style.display = "block";
            document.getElementById("scroll_menubar").classList.add('scroll_menubar');
        }
        else {
            document.getElementById("scroll_navbar").style.top = "-300px";
            document.getElementById("scroll_menubar").style.display = "none";
            document.getElementById("scroll_menubar").classList.remove('scroll_menubar');
        }
    }
    else if (screenWidth <= 991) {
        if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
            document.getElementById("scroll_navbar").style.top = "0%";
            document.getElementById("img_logo").style.display = "block";
            document.getElementById("scroll_menubar").style.display = "block";
            document.getElementById("scroll_menubar").classList.add('scroll_menubar');
        }
        else {
            document.getElementById("scroll_navbar").style.top = "-300px";
            document.getElementById("scroll_menubar").style.display = "none";
            document.getElementById("scroll_menubar").classList.remove('scroll_menubar');
        }
    }
}


function showShoppingCart(cartId) {
    document.getElementById(cartId).style.height = "130px";
}

function hideShoppingCart(hidecartId) {
    document.getElementById(hidecartId).style.height = "0";
}

var likeStorage = [];

function likeToggle(likeId, total_like, likeFlag) {

    var likeCard = JSON.parse(localStorage.getItem('myCards'));
    if (likeFlag) {
        total_like--;
    } else {
        total_like++;
    }     
    likeCard.map(card => {
        if (likeId === card.likeId) {
            card.total_likeValue = total_like;
            card.likeFlag = likeFlag ? false : true;
        }
    })
    localStorage.setItem('myCards', JSON.stringify(likeCard));
    renderData();
}

function showMenubar(menubarId) {
    document.getElementById(menubarId).style.height = "auto";
}

function hideMenubar(hideMenubarId) {
    document.getElementById(hideMenubarId).style.height = "0px";
}

function showSearchbar() {
    document.getElementById('searchbar').classList.add("searchbar");
    document.getElementById('searchbar').classList.remove("searchbar_content");

}

function hideSearchbar() {
    document.getElementById('searchbar').classList.remove("searchbar");
    document.getElementById('searchbar').classList.add("searchbar_content");
}

function search(event) {
    event.stopPropagation();
}

function showStory() {
    document.getElementById('show_story').style.height = "80px";
    document.getElementById('show_story_btn').style.display = "none";
    document.getElementById('blog_data').style.bottom = "80px";
}

function hideStory() {
    document.getElementById('show_story').style.height = "0";
    document.getElementById('blog_data').style.bottom = "0";
    document.getElementById('show_story_btn').style.display = "block";
}

function showMenubar() {
    document.getElementById('navbar_icon_menu').style.display = "block";
    document.getElementById('nav_container').classList.add('nav_animation');
    document.getElementById('nav_container').classList.remove('nav_container');
    document.getElementById('show_story_btn').style.display = "none";
    document.getElementById('add_blog_btn').style.display = "none";
    document.getElementById('home_btn').style.display = "none";

}

function hideMenubar() {
    document.getElementById('show_story_btn').style.display = "block";
    document.getElementById('add_blog_btn').style.display = "block";
    document.getElementById('home_btn').style.display = "block";
    document.getElementById('navbar_icon_menu').style.display = "none";
    document.getElementById('nav_container').classList.remove('nav_animation');
    document.getElementById('nav_container').classList.add('nav_container');
}

function show_changeImgBox() {
    document.getElementById('change_bg').style.right = "1%";
}

function hide_changeImgBox() {
    document.getElementById('change_bg').style.right = "-100%";
}

function addBlog() {
    document.getElementById('add-blog-form').style.display = "flex";

}
function hideAddBlogForm() {
    document.getElementById('add-blog-form').style.display = "none";

}

blog_categoryArray = [];

function category() {
    blog_categoryArray = [];
    var owner_category = document.getElementById('owner-category');
    var category = owner_category.options[owner_category.selectedIndex].text;
    blog_categoryArray.push(category);
}

function validation(inputId,type,errorMessage)
{
    var inputVal = document.getElementById(inputId).value;

    if(inputVal.trim() == "" || inputVal == null){
        document.getElementById(errorMessage).style.display = "flex";
    }
    else{
        document.getElementById(errorMessage).style.display = "none ";
    }
}

function urlValidation(event) {
    event.preventDefault();

    var img_url = document.getElementById("blog-image").value;

    var url = /^((https?|ftp|smtp):\/\/)?(www.)?[a-z0-9]+\.[a-z]+(\/[a-zA-Z0-9#]+\/?)*$/;
    var urlRes = url.exec(img_url);

    if (urlRes == null) {
        document.getElementById("urlErrorMessage").style.display = " flex"
    }
    else {
        document.getElementById("urlErrorMessage").style.display = " none"
    }
}

var submit = document.getElementById('btnsubmit');

submit.addEventListener('onclick', function (e) {
    e.preventDefault();
    validateForm();
});

var flag = false;
function validateForm(event) {
    event.preventDefault();

    // //name validation
    var name = document.getElementById("blogger-name").value;
    // var letters = /^[A-Za-z\s]+$/;
    // var res = letters.exec(name);
    // if (res == null) {
    //     document.getElementById("nameErrorMessage").style.display = " flex"
    // }
    // else {
    //     document.getElementById("nameErrorMessage").style.display = " none"
    // }

    // //blog title validation
    var blog_title = document.getElementById("blog-title").value;
    // var blog_titleRes = letters.exec(blog_title);
    // if (blog_titleRes == null) {
    //     document.getElementById("blogTitleErrorMessage").style.display = " flex"
    // }
    // else {
    //     document.getElementById("blogTitleErrorMessage").style.display = " none"
    // }
    // // blogger category
    // var select = document.getElementById('owner-category');
    // if (select.value) {
    // }
    // if (select == " ") {
    //     document.getElementById("categoryErrorMessage").style.display = " flex"
    // }
    // else {
    //     document.getElementById("categoryErrorMessage").style.display = " none"
    // }

    // //blogger description validation
    var blogger_description = document.getElementById("blogger-description").value;
    // if (blogger_description == null) {
    //     document.getElementById("descriptionErrorMessage").style.display = " flex"
    // }
    // else {
    //     document.getElementById("descriptionErrorMessage").style.display = " none"
    // }

    // //image url validation
    var img_url = document.getElementById("blog-image").value;


    //number of likes animation

    var no_likes = document.getElementById("blog-like").value;

    // if (no_likes == " ") {
    //     document.getElementById("likeErrorMessage").style.display = " flex"
    // }
    // else {
    //     document.getElementById("likeErrorMessage").style.display = " none"
    // }

if (name == null || name == " " || blog_title == null || blog_title == " " || blogger_description == " " || blogger_description == null ||  img_url == " " || img_url == null || no_likes == " "|| no_likes == null) {
    console.log("------");
    return false;
}

    // flag = true;
    validateCard();
}


function validateCard() {
    var myCards = JSON.parse(localStorage.getItem('myCards'));

    var card_bg_img = document.getElementById('blog-image').value;
    var blog_like = document.getElementById('blog-like').value;
    var blog_title = document.getElementById("blog-title").value;
    var blogger_description = document.getElementById("blogger-description").value;
    var name = document.getElementById("blogger-name").value;

    const monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"]

    var today = new Date();
    var date = monthNames[(today.getMonth())] + ' ' + today.getDate() + ' ' + today.getFullYear();
    var blogger_category = blog_categoryArray[0];

    var addCard = [];
    
    if (myCards == " " || myCards == null) {
        addCard = window.cardStorage;
        row_Index = addCard.length + 1;
        console.log('row_Index : ' + row_Index);

    } else {
        addCard = myCards;
        row_Index = addCard.length + 1;
    }

    var rowBlogData = {

        url: card_bg_img,
        likeId: `like${row_Index}`,
        dislikeId: `dislike${row_Index}`,
        total_likeId: `total_like${row_Index}`,
        total_likeValue: blog_like,
        category: blogger_category,
        title: blog_title,
        description: blogger_description,
        name: name,
        date: date,
        likeFlag: false
    };

    addCard.push(rowBlogData);

    localStorage.setItem('myCards', JSON.stringify(addCard));

    add_blog.reset();
    document.getElementById('add-blog-form').style.display = "none";

    renderData();

}
