var myCard;
window.cardStorage = myCard = [{
    url: "./assets/images/pexels-photo-3353994.jpeg",
    likeId: "like1",
    dislikeId: "dislike1",
    total_likeId: "total_like1",
    total_likeValue: "85",
    category: "TRAVEL",
    title: "I-Phone",
    description: "this the description this the description this the description this the description this the description this the description",
    name: "VINEET",
    date: "DECEMBER 21 2020",
    likeFlag: false
},
{
    url: "./assets/images/pexels-photo-3353994.jpeg",
    likeId: "like2",
    dislikeId: "dislike2",
    total_likeId: "total_like2",
    total_likeValue: "85",
    category: "TECHNOLOGY",
    title: "Poco F1",
    description: "this the description this the description this the description this the description this the description this the description",
    name: "SAURIN",
    date: "DECEMBER 21 2020",
    likeFlag: false
},
{
    url: "./assets/images/pexels-photo-3361704.jpeg",
    likeId: "like3",
    dislikeId: "dislike3",
    total_likeId: "total_like3",
    total_likeValue: "85",
    category: "FASHION",
    title: "Samsung",
    description: "this the description this the description this the description this the description this the description this the description",
    name: "MEHUL",
    date: "DECEMBER 21 2020",
    likeFlag: false
}
];



var myCards = [];

window.onload = function () {
    
    renderData();
}

function renderData() {
    
    var cards = document.getElementById('cards');
    myCards = JSON.parse(localStorage.getItem('myCards'));
    if (myCards == null || myCards == " ") {
        console.log('BLANK');
        localStorage.setItem('myCards', JSON.stringify(myCard));
        // myCards = myCard;
    }


    var newcard = ``;
    var myCardsLen = myCards.length;
    for (var i = 0; i < myCardsLen; i++) {
        newcard += `<div class="card">
                <div class="card_img_wrapper">
                    <div class="card_img">
                        <img  class="card_bg_img" src=${myCards[i].url} alt="photo">
                    </div>
                </div>
            
                <div class="like_button">
                    <i class="fa ${myCards[i].likeFlag ? 'fa-heart' : 'fa-heart-o'}"  id="${myCards[i].likeId}" onclick="likeToggle('${myCards[i].likeId}',${myCards[i].total_likeValue}, ${myCards[i].likeFlag})"></i>
                    <span id=${myCards[i].total_likeId}>${myCards[i].total_likeValue}</span>
                </div>
                
                <div class="card_body">
                    <h3 class="category">${myCards[i].category} </h3>
                    <h2 class="blog_title">${myCards[i].title}</h2>
                    <p class="blogger_description">${myCards[i].description}</p>
                    <div class="blog_info">   
                        <span class="blogger_name">${myCards[i].name}</span><code> - </code><span class="blogger_date">${myCards[i].date}</span>
                    </div>
                    
                    <div class="card_link">
                        <i class="card_link_icon fa fa-facebook"></i>
                        <i class="card_link_icon fa fa-google"></i>
                        <i class="card_link_icon fa fa-pinterest-p"></i>
                        <i class="card_link_icon fa fa-twitter"></i>
                        <i class="card_link_icon fa fa-vine"></i>
                    </div>
                </div>
            </div>`
    }
    cards.innerHTML = newcard;
}
